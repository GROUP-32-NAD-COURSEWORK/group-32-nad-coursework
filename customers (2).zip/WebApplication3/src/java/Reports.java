/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */

import java.io.IOException;
import java.io.PrintWriter;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

/**
 *
 * @author user
 */
public class Reports extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try ( PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet Reports</title>");            
            out.println("</head>");
            out.println("<body>");
            out.println("<h1> Reports</h1>");
            String form=" <form action=\"/yenkidemo/Saveuser\" method=\"POST\">\n" +
"        <table>\n" +
"            <tr>\n" +
"                <td>customername</td>\n" +
"            <td><input type=\"text\" name=\"customername\"></td>\n" +
"            </tr>\n" +
"            <tr>\n" +
"                <td>productsneeded</td>\n" +
"            <td><input type=\"text\" name=\"productsneeded\"></td>\n" +
"            </tr>\n" +
"            \n" +
"            <tr>\n" +
"                <td>customerslocation</td>\n" +
"            <td><input type=\"text\" name=\"customerslocation\"></td>\n" +
"            </tr>\n" +
"            <tr>\n" +
"                <td>quantityneeded</td>\n" +
"            <td><input type=\"text\" name=\"quantityneeded\"></td>\n" +
"            </tr>\n" +
                    
                    
 "                   <tr>\n" +
"               <td>gender</td>\n" +
"            <td><label>male</label></td>\n" +
"           <td> <input type=\"radio\" label=\"male\" name=\"gender\" value=\"male\" ></td>\n" +
"           <td><label>female</label></td>\n" +
"           <td><input type=\"radio\" label=\"female\" name=\"gender\" value=\"female\"></td>\n" +
          
"            </tr>\n" +
                    
                    
"            \n" +
"            \n" +
"             <tr></tr>\n" +
"            <td><input type=\"Submit\" name=\"sub\" value=\"Submit\"></td>\n" +
"            </tr>\n" +
"        </table>\n" +
"        </form>" ;
             out.println(form);
            out.println("</body>");
            out.println("</html>");
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
